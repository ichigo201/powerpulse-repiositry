# MOTORA — European Vehicle Marketplace (Sprint 1 prototype)

A runnable Next.js prototype for cars and motorcycles. Supports English, German, Lithuanian and Polish navigation; search over explicitly fictional demo vehicles; and a placeholder dealer dashboard.

## Start

```bash
npm install
npm run dev
```

Open http://localhost:3000. `npm run build` checks the production build.

## Database

Create a development Supabase project and review `supabase/migrations/001_initial.sql` before applying it. The frontend is **not yet connected** to Supabase. The migration enables RLS and public read-only policies for verified dealer listings. No dealer writes or inquiry writes are enabled yet.

## Status and next sprint

- Done: responsive homepage, search route, demo cards, locale routes, draft schema, health endpoint.
- Not done: real database connectivity, dealer authentication, production translations review, image uploads, approved dealer feeds, inquiry submission, security tests, legal policies.
- Do not publish as a functioning marketplace or accept personal data before these are implemented and reviewed.
- MOTORA is a placeholder name; check domain and trademark availability before branding.

## Budget

Target €5,000 total. Prioritize dealer validation and authorized feeds before paid development or promotion.
