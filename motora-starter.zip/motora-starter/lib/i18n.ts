export const locales=['en','de','lt','pl'] as const;
export type Locale=typeof locales[number];
export const copy={
 en:{headline:'Your next vehicle. Across borders.',sub:'Explore cars and motorcycles from European dealerships.',search:'Search vehicles',cars:'Cars',moto:'Motorcycles',dealer:'Dealer dashboard'},
 de:{headline:'Dein naechstes Fahrzeug. Grenzenlos.',sub:'Entdecke Autos und Motorraeder europaeischer Haendler.',search:'Fahrzeuge suchen',cars:'Autos',moto:'Motorraeder',dealer:'Haendlerbereich'},
 lt:{headline:'Kitas tavo automobilis ar motociklas. Be sienu.',sub:'Atrask Europos pardaveju automobilius ir motociklus.',search:'Ieskoti transporto',cars:'Automobiliai',moto:'Motociklai',dealer:'Pardavejo zona'},
 pl:{headline:'Twoj nastepny pojazd. Bez granic.',sub:'Odkrywaj samochody i motocykle europejskich dealerow.',search:'Szukaj pojazdow',cars:'Samochody',moto:'Motocykle',dealer:'Panel dealera'}
} as const;
export function localeOf(v:string):Locale{return locales.includes(v as Locale)?v as Locale:'en'}
