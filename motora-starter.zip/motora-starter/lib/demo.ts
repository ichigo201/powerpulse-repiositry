// Demonstration records only. Replace with approved dealer inventory before public launch.
export const demo=[
{id:'demo-1',type:'car',make:'BMW',model:'330i',year:2021,price:28900,km:58000,country:'Germany'},
{id:'demo-2',type:'car',make:'Audi',model:'A4 Avant',year:2020,price:24500,km:72000,country:'Germany'},
{id:'demo-3',type:'motorcycle',make:'Yamaha',model:'MT-09',year:2022,price:8900,km:14000,country:'Germany'},
{id:'demo-4',type:'motorcycle',make:'Honda',model:'CBR650R',year:2021,price:7350,km:21000,country:'Germany'}] as const;
