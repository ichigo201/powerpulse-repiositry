import './globals.css';
export const metadata = {title:'MOTORA | European Vehicle Marketplace',description:'Explore vehicles across Europe. Pilot marketplace concept.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
