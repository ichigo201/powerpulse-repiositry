-- Initial schema. Apply in a development Supabase project; RLS enabled on all tables.
create extension if not exists pgcrypto;
create table public.dealers (id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), company_name text not null, country_code char(2) not null, verification_status text not null default 'pending' check(verification_status in ('pending','verified','rejected')), created_at timestamptz not null default now());
create table public.vehicles (id uuid primary key default gen_random_uuid(), category text not null check(category in ('car','motorcycle')), make text not null, model text not null, model_year integer check(model_year between 1900 and 2100), mileage_km integer check(mileage_km>=0), fuel_type text, transmission text, power_kw integer check(power_kw>=0));
create table public.listings (id uuid primary key default gen_random_uuid(), dealer_id uuid not null references public.dealers(id), vehicle_id uuid not null unique references public.vehicles(id), price_eur numeric(12,2) not null check(price_eur>=0), status text not null default 'draft' check(status in ('draft','pending','published','archived')), source_ref text, published_at timestamptz, expires_at timestamptz, created_at timestamptz not null default now(), unique(dealer_id,source_ref));
create table public.vehicle_images (id uuid primary key default gen_random_uuid(), listing_id uuid not null references public.listings(id) on delete cascade, storage_path text not null, sort_order integer not null default 0);
create table public.listing_translations (listing_id uuid not null references public.listings(id) on delete cascade, locale text not null check(locale in ('en','de','lt','pl')), title text not null, description text, primary key(listing_id,locale));
create table public.inquiries (id uuid primary key default gen_random_uuid(), listing_id uuid not null references public.listings(id), buyer_email text not null, message text not null, created_at timestamptz not null default now());
create index listings_public_idx on public.listings(status,price_eur,published_at desc);
create index vehicles_search_idx on public.vehicles(category,make,model,model_year);
create index listings_dealer_idx on public.listings(dealer_id);
alter table public.dealers enable row level security;
alter table public.vehicles enable row level security;
alter table public.listings enable row level security;
alter table public.vehicle_images enable row level security;
alter table public.listing_translations enable row level security;
alter table public.inquiries enable row level security;
-- Only verified published inventory is public. Admin policies and dealer write operations are deliberately deferred until audited.
create policy public_listings_read on public.listings for select to anon,authenticated using (status='published' and exists(select 1 from public.dealers d where d.id=dealer_id and d.verification_status='verified'));
create policy public_vehicles_read on public.vehicles for select to anon,authenticated using (exists(select 1 from public.listings l join public.dealers d on d.id=l.dealer_id where l.vehicle_id=vehicles.id and l.status='published' and d.verification_status='verified'));
create policy public_images_read on public.vehicle_images for select to anon,authenticated using (exists(select 1 from public.listings l join public.dealers d on d.id=l.dealer_id where l.id=listing_id and l.status='published' and d.verification_status='verified'));
create policy public_translations_read on public.listing_translations for select to anon,authenticated using (exists(select 1 from public.listings l join public.dealers d on d.id=l.dealer_id where l.id=listing_id and l.status='published' and d.verification_status='verified'));
